/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author IsmaO
 */
public class Clase_Principal {
    public static void main (String [] aregs)
    {
        P_Program MenuP = new P_Program();
        MenuP.setVisible(true);
    }
    
}
